package com.cg;

public class User {

}
